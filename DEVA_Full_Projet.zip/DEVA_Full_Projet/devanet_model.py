# devanet_model.py

import torch
import torch.nn as nn

from deva import TextEncoder
from devanet_modules import (
    AudioVisualFeatureProjector,
    MFU,
)


class DEVANet(nn.Module):
    """
    Version pédagogique DEVA :
    - encode le texte en X_t
    - projette audio/vidéo en X_a, X_v
    - enrichit X_t avec D_a (AED) et D_v (VED)
    - applique MFU (text-guided fusion)
    - prédit la valence (régression)
    """

    def __init__(self,
                 audio_in_dim,
                 video_in_dim,
                 T=8,
                 d_model=128,
                 num_mfu_layers=2):
        super().__init__()

        self.d_model = d_model
        self.T = T

        # 1) Encodeur texte (ton TextEncoder)
        self.text_encoder = TextEncoder(bert_pretrained="bert-base-uncased")

        # 2) Projeter audio/vidéo vers X_a, X_v
        self.projector = AudioVisualFeatureProjector(
            audio_in_dim=audio_in_dim,
            video_in_dim=video_in_dim,
            d_model=d_model,
            T=T
        )

        # 3) MFU (plusieurs couches)
        self.mfu_layers = nn.ModuleList(
            [MFU(d_model=d_model) for _ in range(num_mfu_layers)]
        )

        # 4) Optionnel : petite projection après concat X_t + D_a + D_v
        # Ici on prend les 8 premiers tokens après avoir enrichi le texte
        self.text_fusion_proj = nn.Linear(d_model, d_model)

        # 5) Tête de régression finale
        self.regressor = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.ReLU(),
            nn.Linear(d_model, 1)
        )

    def forward(self, bert_triplet, audio_feat, video_feat, D_a, D_v):
        """
        bert_triplet : [B, 3, L]
        audio_feat   : [B, Ta, audio_in_dim]
        video_feat   : [B, Tv, video_in_dim]
        D_a          : [B, 1, d_model]
        D_v          : [B, 1, d_model]
        """
        B = bert_triplet.size(0)

        # 1) Texte -> X_t brut
        X_t_raw = self.text_encoder(bert_triplet)   # [B, 8, d_model]

        # 2) Enrichir X_t avec D_a et D_v
        # D_a et D_v sont déjà dans l'espace 128-dim (via TextEncoder AED/VED)
        # On les concatène comme tokens supplémentaires
        X_t_aug = torch.cat([X_t_raw, D_a, D_v], dim=1)  # [B, 10, d_model]

        # On garde comme "fusion" initiale seulement les 8 premiers tokens texte
        fusion = self.text_fusion_proj(X_t_raw)  # [B, 8, d_model]

        # 3) Projeter l'audio et la vidéo
        X_a, X_v = self.projector(audio_feat, video_feat)  # [B, 8, d_model]

        # 4) MFU guidé par X_t_aug (texte + AED + VED)
        for mfu in self.mfu_layers:
            fusion = mfu(fusion, X_t_aug, X_a, X_v)  # [B, 8, d_model]

        # 5) Pooling sur la dimension temporelle
        pooled = fusion.mean(dim=1)  # [B, d_model]

        # 6) Prédiction finale (valence)
        out = self.regressor(pooled)  # [B, 1]

        return out
