"""
@name: deva.py
@description: Implémentation du modèle DEVA avec intégration complète
              d'un TextEncoder basé sur BERT.
              Ce modèle réalise une fusion multimodale avancée entre
              texte, audio, vision et représentations croisés A-T / V-T.
"""

import torch
from torch import nn
import torch.nn.functional as F
from einops import repeat

# Import des modules existants
from bert import BertTextEncoder
from tpf_layer import Transformer, CrossTransformer, TPFLearningEncoder


# ============================================================
#              TEXTENCODER (VERSION SPÉCIFIQUE DEVA)
# ============================================================

class TextEncoder(nn.Module):
    """
    Encodeur de texte utilisé dans DEVA :
    - Passage par BERT (fine-tuned)
    - Projection vers un embedding de dimension D
    - Ajout d'un token spécial E_m (token régulateur)
    - Ajout d'encodage positionnel appris
    - Passage par un TransformerEncoderLayer
    - Extraction des premiers T tokens comme représentation textuelle
    """
    def __init__(self, bert_pretrained="bert-base-uncased", T=8, D=128):
        super().__init__()

        # Module BERT pré-entraîné
        self.bert = BertTextEncoder(
            use_finetune=True,
            transformers="bert",
            pretrained=bert_pretrained
        )

        # Projection 768 → D (128)
        self.proj = nn.Linear(768, D)

        # Token spécial apprenable
        self.E_m = nn.Parameter(torch.zeros(1, 1, D))

        # Encodage positionnel appris
        self.pos_emb = nn.Parameter(torch.randn(1, 60, D) * 0.01)

        # Transformer minimal pour raffiner les embeddings textuels
        self.encoder = nn.TransformerEncoderLayer(
            d_model=D,
            nhead=8,
            dim_feedforward=256,
            dropout=0.1,
            batch_first=True,
            norm_first=True
        )

        self.layernorm = nn.LayerNorm(D)
        self.T = T  # nombre de tokens textuels à conserver

    def forward(self, bert_triplet):
        """
        bert_triplet : [B, 3, L]
        Retourne : [B, T, D]
        """

        # ---- 1) Encodage BERT ---------------------------------
        x = self.bert(bert_triplet)     # [B, L, 768]

        # ---- 2) Projection de dimension ------------------------
        x = self.proj(x)                # [B, L, D]

        # ---- 3) Ajout positionnel ------------------------------
        x = x + self.pos_emb[:, :x.size(1), :]

        # ---- 4) Ajout du token E_m ------------------------------
        B = x.size(0)
        E = self.E_m.expand(B, -1, -1)  # [B,1,D]
        x = torch.cat([E, x], dim=1)    # [B,1+L,D]

        # ---- 5) Normalisation avant Transformer ----------------
        x = self.layernorm(x)

        # ---- 6) Passage par une couche Transformer --------------
        x = self.encoder(x)             # [B,1+L,D]

        # ---- 7) Extraction des T premiers tokens ----------------
        return x[:, :self.T, :]



# ============================================================
#                          MODÈLE DEVA
# ============================================================

class DEVA(nn.Module):
    """
    Implémentation complète du modèle DEVA :
    - Encodeurs unimodaux pour audio / vision
    - Encodeurs croisés audio-texte et vision-texte
    - Fusion multimodale via MFU (Token-Pivot Fusion)
    - Fusion finale via CrossTransformer
    - Tête linéaire pour prédiction de sentiment / regression
    """
    def __init__(self, dataset, MFU_depth=3,
                 fusion_layer_depth=2,
                 bert_pretrained='bert-base-uncased'):

        super(DEVA, self).__init__()

        # ----------------------------------------------------------------
        # h_minor = token pivot multimodal (apprenable)
        # ----------------------------------------------------------------
        self.h_minor = nn.Parameter(torch.ones(1, 8, 128))

        # Encodeur de texte DEVA complet
        self.text_encoder = TextEncoder(
            bert_pretrained=bert_pretrained,
            d_model=128,
            T=8
        )

        # ----------------------------------------------------------------
        #                Projection AUDIO / VISION / A-T / V-T
        # ----------------------------------------------------------------

        # Selon le dataset, les dimensions ne sont pas identiques
        if dataset == 'mosi':
            self.proj_a0 = nn.Linear(5,   128)
            self.proj_v0 = nn.Linear(20,  128)

        elif dataset == 'mosei':
            self.proj_a0 = nn.Linear(74,  128)
            self.proj_v0 = nn.Linear(35,  128)

        elif dataset == 'sims':
            self.proj_a0 = nn.Linear(33,  128)
            self.proj_v0 = nn.Linear(709, 128)

        else:
            raise ValueError("Dataset must be mosi, mosei, or sims.")

        # Projections audio-text & vision-text (768 → 128)
        self.proj_al0 = nn.Linear(768, 128)
        self.proj_vl0 = nn.Linear(768, 128)

        # Encodage Transformer par modalité (8 tokens + frames)
        self.proj_a  = Transformer(num_frames=50, token_len=8, dim=128, depth=1, heads=8, mlp_dim=128)
        self.proj_v  = Transformer(num_frames=50, token_len=8, dim=128, depth=1, heads=8, mlp_dim=128)
        self.proj_al = Transformer(num_frames=50, token_len=8, dim=128, depth=1, heads=8, mlp_dim=128)
        self.proj_vl = Transformer(num_frames=50, token_len=8, dim=128, depth=1, heads=8, mlp_dim=128)

        # ----------------------------------------------------------------
        #                   MFU : Multimodal Fusion Unit
        #     (fusion avancée via TPF : Token-Pivot-Fusion Encoder)
        # ----------------------------------------------------------------
        self.h_tpf_layer = TPFLearningEncoder(
            dim=128,
            depth=MFU_depth,
            heads=8,
            dim_head=16
        )

        # ----------------------------------------------------------------
        #                     CROSS-TRANSFORMER FINAL
        # ----------------------------------------------------------------
        self.fusion_layer = CrossTransformer(
            source_num_frames=8,
            tgt_num_frames=8,
            dim=128,
            depth=fusion_layer_depth,
            heads=8,
            mlp_dim=128
        )

        # ----------------------------------------------------------------
        #                      COUCHES DE FUSION LOCALES
        # ----------------------------------------------------------------

        # audio + audio_text
        self.aatfusion_dropout = nn.Dropout(0.1)
        self.aatfusion_layer   = nn.Linear(128 + 128, 128)

        # vision + vision_text
        self.vvtfusion_dropout = nn.Dropout(0.1)
        self.vvtfusion_layer   = nn.Linear(128 + 128, 128)

        # texte + vision_text + audio_text
        self.avttfusion_dropout = nn.Dropout(0.0)
        self.avttfusion_layer   = nn.Linear(128 + 128 + 128, 128)

        # ----------------------------------------------------------------
        #                    TÊTE DE PRÉDICTION FINALE
        # ----------------------------------------------------------------
        self.cls_head = nn.Sequential(
            nn.Linear(128, 1)
        )

    # ============================================================
    #                           FORWARD
    # ============================================================

    def forward(self, x_visual, x_audio, x_text, audio_text, vision_text):
        """
        x_text : batch de shape [B, 3, L] (triplet pour BERT)
        audio_text, vision_text : embeddings 768-dim issus de modules A-T et V-T
        """

        b = x_visual.size(0)

        # Réplication du token pivot multimodal
        h_minor = repeat(self.h_minor, '1 n d -> b n d', b=b)

        # =====================================================
        #                    ENCODAGE TEXTE
        # =====================================================
        h_t = self.text_encoder(x_text)    # [B, 8, 128]


        # =====================================================
        #                   ENCODAGE AUDIO / VISION
        # =====================================================
        x_audio = self.proj_a0(x_audio)          # [B, seq, 128]
        x_visual = self.proj_v0(x_visual)        # [B, seq, 128]
        x_audio_text = self.proj_al0(audio_text) # [B, seq, 128]
        x_vision_text = self.proj_vl0(vision_text)

        # Passage par les Transformers unimodaux
        h_a  = self.proj_a(x_audio)[:, :8]
        h_v  = self.proj_v(x_visual)[:, :8]
        h_at = self.proj_al(x_audio_text)[:, :8]
        h_vt = self.proj_vl(x_vision_text)[:, :8]


        # =====================================================
        #                  FUSION AUDIO (A & A-T)
        # =====================================================
        h_fusion_a = torch.cat([h_a, h_at], dim=-1)
        h_fusion_a = self.aatfusion_dropout(h_fusion_a)
        h_fusion_a = F.relu(self.aatfusion_layer(h_fusion_a))


        # =====================================================
        #                  FUSION VISION (V & V-T)
        # =====================================================
        h_fusion_v = torch.cat([h_v, h_vt], dim=-1)
        h_fusion_v = self.vvtfusion_dropout(h_fusion_v)
        h_fusion_v = F.relu(self.vvtfusion_layer(h_fusion_v))


        # =====================================================
        #         FUSION TEXTE + V-T + A-T (triplet textuel)
        # =====================================================
        h_fusion_t = torch.cat([h_vt, h_at, h_t], dim=-1)
        h_fusion_t = self.avttfusion_dropout(h_fusion_t)
        h_fusion_t = F.relu(self.avttfusion_layer(h_fusion_t))


        # =====================================================
        #                MFU ALIGNMENT (TPF)
        # =====================================================
        h_t_list = [h_fusion_t]  # Compatibilité ancienne (liste)

        h_minor = self.h_tpf_layer(
            h_t_list,      # entrée textuelle fusionnée
            h_fusion_a,    # entrée audio fusionnée
            h_fusion_v,    # entrée vision fusionnée
            h_minor        # token pivot
        )

        # =====================================================
        #                  FUSION CROSS-MODAL FINALE
        # =====================================================
        feat = self.fusion_layer(h_minor, h_t_list[-1])[:, 0]  # [B, 128]

        # =====================================================
        #                    PRÉDICTION FINALE
        # =====================================================
        output = self.cls_head(feat)

        return output


# ============================================================
#                    FONCTION DE CONSTRUCTION
# ============================================================

def build_model(opt):
    """
    Sélectionne le bon modèle BERT (anglais/chinois) selon le dataset,
    puis construit l'instance DEVA complète.
    """
    if opt.datasetName == 'sims':
        l_pretrained = 'bert-base-chinese'
    else:
        l_pretrained = 'bert-base-uncased'

    model = DEVA(
        dataset=opt.datasetName,
        fusion_layer_depth=opt.fusion_layer_depth,
        bert_pretrained=l_pretrained
    )

    return model
