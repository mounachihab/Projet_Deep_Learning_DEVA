import numpy as np
from sklearn.metrics import f1_score, accuracy_score, mean_absolute_error
from scipy.stats import pearsonr


def evaluate_metrics(labels, preds):
    """
    labels : array [N]
    preds  : array [N]
    Retourne : Acc-2, F1, MAE, Corr
    """

    labels = np.array(labels)
    preds = np.array(preds)

    # Binarisation à 0
    labels_bin = (labels >= 0).astype(int)
    preds_bin = (preds >= 0).astype(int)

    acc2 = accuracy_score(labels_bin, preds_bin)
    f1 = f1_score(labels_bin, preds_bin, average='weighted')
    mae = mean_absolute_error(labels, preds)

    if len(labels) > 1:
        corr, _ = pearsonr(labels, preds)
    else:
        corr = 0.0

    return {
        "Acc-2": acc2,
        "F1": f1,
        "MAE": mae,
        "Corr": corr
    }
