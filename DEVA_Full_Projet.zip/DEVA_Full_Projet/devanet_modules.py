"""
Ce script regroupe trois composants essentiels pour une fusion multimodale
guidée par le texte. 
- Le bloc CrossModalAttention implémente une attention
croisée permettant à une modalité (audio ou vidéo) d’interroger les
représentations textuelles. 
- Le module MFU (Minor Fusion Unit) réalise une
fusion résiduelle contrôlée par deux coefficients apprenables, combinant les
influences audio et vidéo guidées par le texte. 
- AudioVisualFeatureProjector projette les features brutes audio et vidéo dans
un espace commun puis les normalise via un encodeur Transformer léger.
Ces trois éléments forment un pipeline compact et efficace pour la fusion
audio–vidéo–texte.
"""


import torch
import torch.nn as nn
import torch.nn.functional as F


# -----------------------------------------------------------------------
# 1) Attention Croisée (Scaled Dot-Product)
# -----------------------------------------------------------------------
class CrossModalAttention(nn.Module):
    """
    Attention croisée : une modalité Q regarde une autre modalité (K,V).
    Q vient de X_a ou X_v ; K et V viennent de X_t.
    """

    def __init__(self, d_model=128):
        super().__init__()
        self.q_proj = nn.Linear(d_model, d_model)
        self.k_proj = nn.Linear(d_model, d_model)
        self.v_proj = nn.Linear(d_model, d_model)
        self.scale = d_model ** 0.5

    def forward(self, q, k, v, mask=None):
        """
        q : [B, Tq, D]
        k : [B, Tk, D]
        v : [B, Tk, D]
        """
        Q = self.q_proj(q)
        K = self.k_proj(k)
        V = self.v_proj(v)

        scores = torch.matmul(Q, K.transpose(-2, -1)) / self.scale

        if mask is not None:
            scores = scores.masked_fill(mask == 0, -1e9)

        attn = torch.softmax(scores, dim=-1)
        out = torch.matmul(attn, V)
        return out, attn


# -----------------------------------------------------------------------
# 2) MFU (Minor Fusion Unit)
# -----------------------------------------------------------------------
class MFU(nn.Module):
    """
    Fusion résiduelle text-guided :
    prev + α * Att_{T->A}(X_a, X_t) + β * Att_{T->V}(X_v, X_t)
    """

    def __init__(self, d_model=128):
        super().__init__()
        self.att_t2a = CrossModalAttention(d_model)
        self.att_t2v = CrossModalAttention(d_model)

        # α et β scalaires learnables
        self.alpha = nn.Parameter(torch.tensor(0.5))
        self.beta = nn.Parameter(torch.tensor(0.5))

    def forward(self, prev_fusion, X_t, X_a, X_v):
        att_a, _ = self.att_t2a(X_a, X_t, X_t)
        att_v, _ = self.att_t2v(X_v, X_t, X_t)

        out = prev_fusion + self.alpha * att_a + self.beta * att_v
        return out


# -----------------------------------------------------------------------
# 3) AudioVisualFeatureProjector
# Transforme les features brutes en X_a, X_v alignés
# -----------------------------------------------------------------------
class AudioVisualFeatureProjector(nn.Module):

    def __init__(self, audio_in_dim, video_in_dim,
                 d_model=128, T=8):
        super().__init__()
        self.T = T
        self.d_model = d_model

        # Projections
        self.audio_proj = nn.Linear(audio_in_dim, d_model)
        self.video_proj = nn.Linear(video_in_dim, d_model)

        # Encodeurs simples
        a_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=4,
            dim_feedforward=4*d_model, batch_first=True
        )
        v_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=4,
            dim_feedforward=4*d_model, batch_first=True
        )

        self.audio_encoder = nn.TransformerEncoder(a_layer, num_layers=1)
        self.video_encoder = nn.TransformerEncoder(v_layer, num_layers=1)

    def _fix_length(self, x):
        """
        Pad/tronque pour obtenir exactement T tokens.
        """
        B, T_raw, D = x.shape

        if T_raw > self.T:
            return x[:, :self.T]
        elif T_raw < self.T:
            pad = x.new_zeros(B, self.T - T_raw, D)
            return torch.cat([x, pad], dim=1)
        return x

    def forward(self, audio_feat, video_feat):
        """
        audio_feat : [B, Ta, audio_in_dim]
        video_feat : [B, Tv, video_in_dim]
        """
        a = self.audio_proj(audio_feat)
        v = self.video_proj(video_feat)

        a = self.audio_encoder(a)
        v = self.video_encoder(v)

        X_a = self._fix_length(a)
        X_v = self._fix_length(v)

        return X_a, X_v
