"""Ce script vérifie Pour chaque ID, il valide ou non l’existence 
de ces fichiers dans leurs répertoires respectifs. : 
- transcription, 
- audio, 
- vidéo réduite,
- embeddings AED 
- et embeddings VED. 
Les IDs complets sont enregistrés dans ids_clean.txt.
Cela permet de s’assurer que seuls 
les échantillons parfaitement complets sont utilisés pour l’entraînement ou 
l’évaluation du modèle multimodal."""

import os
import pandas as pd

ROOT = "MOSI_full"

# dossiers
dirs = {
    "transcript": os.path.join(ROOT, "transcript"),
    "audio": os.path.join(ROOT, "features_audio"),
    "video": os.path.join(ROOT, "features_video_reduced"),
    "aed": os.path.join(ROOT, "AED_features"),
    "ved": os.path.join(ROOT, "VED_features"),
}

# Charger les labels
labels = pd.read_csv(os.path.join(ROOT, "labels.csv"))
valid_ids = labels["id"].astype(str).tolist()

clean_ids = []

missing = {
    "transcript": [],
    "audio": [],
    "video": [],
    "aed": [],
    "ved": []
}

for vid in valid_ids:
    ok = True

    # Check transcript
    if not (
        os.path.exists(os.path.join(dirs["transcript"], f"{vid}.txt")) or
        os.path.exists(os.path.join(dirs["transcript"], f"{vid}.text")) or
        os.path.exists(os.path.join(dirs["transcript"], f"{vid}.textonly"))
    ):
        ok = False
        missing["transcript"].append(vid)

    # Check audio
    if not os.path.exists(os.path.join(dirs["audio"], f"{vid}.pt")):
        ok = False
        missing["audio"].append(vid)

    # Check video reduced
    if not os.path.exists(os.path.join(dirs["video"], f"{vid}.csv")):
        ok = False
        missing["video"].append(vid)

    # Check AED
    if not os.path.exists(os.path.join(dirs["aed"], f"{vid}_AED.pt")):
        ok = False
        missing["aed"].append(vid)

    # Check VED
    if not os.path.exists(os.path.join(dirs["ved"], f"{vid}_VED.pt")):
        ok = False
        missing["ved"].append(vid)

    if ok:
        clean_ids.append(vid)

# Write valid IDs
with open(os.path.join(ROOT, "ids_clean.txt"), "w") as f:
    for vid in clean_ids:
        f.write(vid + "\n")

print("✔ IDs valides :", len(clean_ids))
print("❌ IDs manquants :", len(valid_ids) - len(clean_ids))

print("\n--- Résumé des fichiers manquants ---")
for k, v in missing.items():
    print(k, ":", len(v))
