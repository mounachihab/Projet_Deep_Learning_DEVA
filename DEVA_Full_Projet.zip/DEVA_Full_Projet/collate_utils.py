import torch
from torch.nn.utils.rnn import pad_sequence

def collate_fn(batch, tokenizer):
    """
    Prépare un batch pour DEVA :
      - Tokenize le texte
      - Empile audio_feat
      - Empile video_feat
      - Empile D_a, D_v
      - Empile labels
    """

    texts = [sample["text"] for sample in batch]
    audio_feats = [sample["audio_feat"] for sample in batch]     # [Ta, D_a]
    video_feats = [sample["video_feat"] for sample in batch]     # [Tv, D_v]
    D_as = [sample["D_a"] for sample in batch]                   # [1,8,128]
    D_vs = [sample["D_v"] for sample in batch]                   # [1,8,128]
    labels = torch.stack([sample["label"] for sample in batch])  # [B]

    # ------------------------
    # 1) TEXT → BERT triplet
    # ------------------------
    encoded = tokenizer(
        texts,
        return_tensors="pt",
        padding="longest",
        truncation=True,
        max_length=50
    )

    # Couper dans les 3 tenseurs : input_ids, attention_mask, token_type_ids
    bert_triplet = torch.stack([
        encoded["input_ids"],
        encoded["attention_mask"],
        encoded["token_type_ids"]
    ], dim=1)   # shape : [B, 3, L]

    # ------------------------
    # 2) AUDIO FEAT
    # ------------------------
    # pad_sequence pour aligner en batch
    audio_feat = pad_sequence(audio_feats, batch_first=True)  # [B, Ta, audio_dim]

    # ------------------------
    # 3) VIDEO FEAT
    # ------------------------
    video_feat = pad_sequence(video_feats, batch_first=True)  # [B, Tv, video_dim]

    # ------------------------
    # 4) D_a / D_v
    # ------------------------
    D_a = torch.cat(D_as, dim=0)   # [B, 8, 128]
    D_v = torch.cat(D_vs, dim=0)   # [B, 8, 128]

    return bert_triplet, audio_feat, video_feat, D_a, D_v, labels
