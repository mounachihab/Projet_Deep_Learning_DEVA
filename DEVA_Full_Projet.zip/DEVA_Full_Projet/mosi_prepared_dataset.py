import os 
import pandas as pd
import torch
from torch.utils.data import Dataset


class MOSIPreparedDataset(Dataset):
    """
    Dataset MOSI adapté pour DEVA + collate_utils.
    Charge :
      - texte brut
      - audio_feat  (MFCC alignés, .pt)
      - video_feat  (OpenFace CSV réduit : AU uniquement, max 50 frames)
      - AED (D_a)
      - VED (D_v)
      - label de sentiment
    """

    def __init__(self,
                 ids_path,
                 labels_csv,
                 transcript_dir,
                 audio_feat_dir,
                 video_feat_dir,
                 aed_dir,
                 ved_dir):

        super().__init__()

        # ------------------------------
        # Load IDs
        # ------------------------------
        with open(ids_path, "r") as f:
            self.ids = [line.strip() for line in f if line.strip()]

        # ------------------------------
        # Load labels
        # ------------------------------
        df = pd.read_csv(labels_csv)
        self.labels = {
            row["id"]: float(row["label"]) 
            for _, row in df.iterrows()
        }

        # ------------------------------
        # Paths
        # ------------------------------
        self.transcript_dir = transcript_dir
        self.audio_feat_dir = audio_feat_dir
        self.video_feat_dir = video_feat_dir  
        self.aed_dir = aed_dir
        self.ved_dir = ved_dir

    def __len__(self):
        return len(self.ids)

    # ---------------------------------------------------
    #  TEXT LOADING (ROBUST : supporte txt, text, textonly)
    # ---------------------------------------------------
    def _load_text(self, vid_id):
        base = os.path.join(self.transcript_dir, vid_id)

        candidates = [
            base + ".txt",
            base + ".text",
            base + ".textonly",
            base
        ]

        for path in candidates:
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    return f.read().strip()

        raise FileNotFoundError(f"No transcript file for {vid_id}")

    # ---------------------------------------------------
    #  AUDIO FEATURES (MFCC .pt)
    # ---------------------------------------------------
    def _load_audio_feat(self, vid_id):
        path = os.path.join(self.audio_feat_dir, f"{vid_id}.pt")
        if not os.path.exists(path):
            raise FileNotFoundError(f"Missing audio_feat: {path}")
        return torch.load(path)   # [50, audio_dim]

    # ---------------------------------------------------
    #  VIDEO FEATURES (CSV REDUIT -> torch tensor)
    # ---------------------------------------------------
    def _load_video_feat(self, vid_id):
        path = os.path.join(self.video_feat_dir, f"{vid_id}.csv")
        if not os.path.exists(path):
            raise FileNotFoundError(f"Missing video_feat: {path}")

        df = pd.read_csv(path)
        df = df.rename(columns={c: c.strip() for c in df.columns})

        # convert CSV to tensor (already reduced to AU cols + max 50 frames)
        return torch.tensor(df.values, dtype=torch.float32)  # [T, video_dim]

    # ---------------------------------------------------
    #  MAIN ITEM
    # ---------------------------------------------------
    def __getitem__(self, idx):
        vid_id = self.ids[idx]

        text = self._load_text(vid_id)
        audio_feat = self._load_audio_feat(vid_id)
        video_feat = self._load_video_feat(vid_id)

        # AED + VED embeddings from TextEncoder
        D_a = torch.load(os.path.join(self.aed_dir, f"{vid_id}_AED.pt"))  # [1,8,128]
        D_v = torch.load(os.path.join(self.ved_dir, f"{vid_id}_VED.pt"))  # [1,8,128]

        label = torch.tensor(self.labels[vid_id], dtype=torch.float32)

        return {
            "id": vid_id,
            "text": text,
            "audio_feat": audio_feat,
            "video_feat": video_feat,
            "D_a": D_a,
            "D_v": D_v,
            "label": label
        }
