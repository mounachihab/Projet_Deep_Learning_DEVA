'''
* @name: bert.py
* @description: Fonctions et classes liées à l'encodage de texte avec BERT / RoBERTa.
* Ce module fournit une interface simple pour tokeniser et encoder du texte
  à l’aide d’un modèle pré-entraîné basé sur la librairie HuggingFace Transformers.
'''

import torch
import torch.nn as nn
from transformers import BertModel, BertTokenizer, RobertaModel, RobertaTokenizer

__all__ = ['BertTextEncoder']

# --------------------------------------------------------------------
# Dictionnaire simple permettant de choisir dynamiquement entre BERT
# et RoBERTa en fonction du paramètre `transformers`.
# Chaque entrée associe un modèle et son tokenizer.
# --------------------------------------------------------------------
TRANSFORMERS_MAP = {
    'bert': (BertModel, BertTokenizer),
    'roberta': (RobertaModel, RobertaTokenizer),
}


class BertTextEncoder(nn.Module):
    """
    Encodage de texte via un modèle Transformer pré-entraîné de HuggingFace.

    - Peut fonctionner avec BERT ou RoBERTa (paramètre `transformers`)
    - Peut être congelé ou fine-tuné (paramètre `use_finetune`)
    - Utilise explicitement `input_ids`, `attention_mask`, `token_type_ids`
      tels qu’attendus par BertModel / RobertaModel.
    """
    def __init__(self, use_finetune=False, transformers='bert', pretrained='bert-base-uncased'):
        super().__init__()

        # Récupération de la classe tokenizer et modèle depuis la MAP
        tokenizer_class = TRANSFORMERS_MAP[transformers][1]
        model_class = TRANSFORMERS_MAP[transformers][0]

        # Chargement du tokenizer et du modèle pré-entraîné
        self.tokenizer = tokenizer_class.from_pretrained(pretrained)
        self.model = model_class.from_pretrained(pretrained)

        # Si False → on freeze les poids en no_grad()
        self.use_finetune = use_finetune
    
    def get_tokenizer(self):
        """
        Retourne l’objet tokenizer HuggingFace utilisé pour transformer le texte brut
        en input_ids, attention_mask, token_type_ids.
        """
        return self.tokenizer
    
    def forward(self, text):
        """
        Encode un batch déjà tokenisé au format :
            text: shape (batch_size, 3, seq_len)

        Les 3 canaux représentent :
            - text[:, 0, :] → input_ids        : indices des tokens
            - text[:, 1, :] → attention_mask   : masque de padding
            - text[:, 2, :] → segment_ids      : token_type_ids (phrases A/B)

        Retour :
            last_hidden_states : tenseur (batch, seq_len, hidden_dim)
        """
        # Extraction des trois composantes du batch
        input_ids, input_mask, segment_ids = (
            text[:,0,:].long(),
            text[:,1,:].float(),
            text[:,2,:].long()
        )

        # Si fine-tuning activé → gradients autorisés
        if self.use_finetune:
            last_hidden_states = self.model(
                input_ids=input_ids,
                attention_mask=input_mask,
                token_type_ids=segment_ids
            )[0]  # Le premier élément du tuple est la séquence d'états cachés

        # Sinon → on passe en mode inférence sans gradients
        else:
            with torch.no_grad():
                last_hidden_states = self.model(
                    input_ids=input_ids,
                    attention_mask=input_mask,
                    token_type_ids=segment_ids
                )[0]

        return last_hidden_states
